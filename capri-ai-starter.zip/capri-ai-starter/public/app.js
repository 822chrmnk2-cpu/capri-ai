const $ = id => document.getElementById(id);
const chat = $("chat");
let history = JSON.parse(localStorage.getItem("capri_history") || "[]");
let memory = localStorage.getItem("capri_memory") || "";
let voiceOn = true;

function addBubble(text, who, save=true) {
  const el = document.createElement("div");
  el.className = `bubble ${who}`;
  el.textContent = text;
  chat.appendChild(el);
  chat.scrollTop = chat.scrollHeight;
  if (save) {
    history.push({role: who === "capri" ? "assistant" : "user", content: text});
    history = history.slice(-80);
    localStorage.setItem("capri_history", JSON.stringify(history));
  }
}
history.slice(-12).forEach(m => addBubble(m.content, m.role === "assistant" ? "capri" : "user", false));

async function sendMessage(text) {
  if (!text.trim()) return;
  addBubble(text, "user");
  $("message").value = "";
  $("statusText").textContent = "· myślę...";
  try {
    const r = await fetch("/api/chat", {
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({messages:history.slice(-24), memory})
    });
    const data = await r.json();
    const reply = data.reply || data.error || "Coś zakłóciło sygnał.";
    addBubble(reply, "capri");
    if (voiceOn && "speechSynthesis" in window) {
      speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(reply);
      utterance.lang = "pl-PL"; utterance.rate = 1.04; utterance.pitch = 1.12;
      speechSynthesis.speak(utterance);
    }
  } catch {
    addBubble("Nie mogę połączyć się z serwerem. Sprawdź internet albo konfigurację AI.", "capri");
  } finally { $("statusText").textContent = "· gotowa do rozmowy"; }
}
$("composer").addEventListener("submit", e => {e.preventDefault(); sendMessage($("message").value);});
$("voiceBtn").onclick = () => { voiceOn = !voiceOn; $("voiceBtn").textContent = `GŁOS: ${voiceOn ? "WŁ." : "WYŁ."}`; };
$("memoryBtn").onclick = () => { $("memoryText").value = memory; $("memoryDialog").showModal(); };
$("closeMemory").onclick = () => $("memoryDialog").close();
$("saveMemory").onclick = () => { memory = $("memoryText").value; localStorage.setItem("capri_memory", memory); $("memoryDialog").close(); };
$("clearMemory").onclick = () => { memory = ""; history = []; localStorage.removeItem("capri_memory"); localStorage.removeItem("capri_history"); chat.innerHTML = ""; $("memoryText").value = ""; };
$("micBtn").onclick = () => {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) { alert("Dyktowanie nie jest obsługiwane w tej przeglądarce. Możesz użyć mikrofonu klawiatury iPhone'a."); return; }
  const rec = new SR(); rec.lang = "pl-PL"; rec.interimResults = false;
  rec.onresult = e => $("message").value = e.results[0][0].transcript;
  rec.start();
};
$("notifyBtn").onclick = async () => {
  if (!("Notification" in window)) return alert("Ta przeglądarka nie obsługuje powiadomień.");
  const p = await Notification.requestPermission();
  alert(p === "granted" ? "Powiadomienia dozwolone. Prawdziwe wiadomości push wymagają jeszcze skonfigurowania serwera push." : "Nie przyznano zgody na powiadomienia.");
};
if ("serviceWorker" in navigator) navigator.serviceWorker.register("/sw.js").catch(()=>{});
